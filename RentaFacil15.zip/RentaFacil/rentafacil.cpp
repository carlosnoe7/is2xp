#include "rentafacil.h"
#include "ui_rentafacil.h"
#include "registro.h"
#include<QString>
#include <QSqlQuery>
#include<QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QPixmap>
#include <QCompleter>
#include <QFileSystemModel>
//Este es mi comentario de prueba
//Este es el comentario de Noe


RentaFacil::RentaFacil(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::RentaFacil)
{
    ui->setupUi(this);

    //varibale estatica de las fotos




    //Base De Datos:
    //Base De Datos:
    QSqlDatabase db;
    db=QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setPort(3306);
    db.setDatabaseName("rentaFacil");
    db.setUserName("root");
    db.setPassword("");

    if(!db.open()){
        qDebug()<<"Error ";
    }
    else{
          qDebug()<<"Conectada ";
    }

    QSqlQuery catalogo,sacarfoto;
       QString catalogosql;
       QString titulo;
       QPixmap imagen;
       QIcon imagenreal;
       QByteArray foto1;
       QString nombreuser;
       QString llamarpro;


       catalogosql = "select titulo,nUsuarioP from Casa";
       catalogo.exec(catalogosql);
       int counterf = 0;
       int counterc = 0;




       while (catalogo.next()) {
           titulo = catalogo.value(0).toString();
           nombreuser=catalogo.value(1).toString();
           llamarpro="call informacioncat('"+nombreuser+"','"+titulo+"' );";
           sacarfoto.exec(llamarpro);
           sacarfoto.next();
           foto1=sacarfoto.value(13).toByteArray();
           imagen.loadFromData(foto1);
           QIcon foto2(imagen);


           if(imagen.isNull())
           {
           }
           else
           {
           QPushButton *h = new QPushButton();
           h->setAccessibleName(titulo);
           ui->layout->addWidget(h , counterf, counterc, 1, 1);
           QSignalMapper *mapper=new QSignalMapper(this);
           connect(h,SIGNAL(clicked(bool)),mapper,SLOT(map()));
           mapper->setMapping(h,titulo);
           connect(mapper,SIGNAL(mapped(QString)),this,SLOT(darEspecificacion(QString)));
           h->setFixedSize(203, 100);
           h->setIcon(foto2);
           h->setIconSize(QSize(203,100));
           h->setStyleSheet("background-color: rgba(255,255,255,0);");
          //QLabel *label = new QLabel;




           //label->setText(titulo);
           //label->setFixedSize(203, 20);
    QTextEdit *label1=new QTextEdit;
    label1->setText(titulo);
    label1->setMaximumWidth(203);
    label1->setMaximumHeight(50);
    label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
           ui->layout->addWidget(label1, counterf + 1, counterc, 1, 1);
           counterc++;
            }
           if (counterc == 3){
               counterf= counterf + 2;
               counterc = 0;
           }
       }


    QSqlQuery estados1;
    QString buscar;
    buscar="select *from Estado";
    estados1.prepare(buscar);
    estados1.exec();
    while(estados1.next())
    {
        ui->comboBoxEstados->addItem(estados1.value(2).toString());
    }

    ui->lineCP->setValidator(new QIntValidator(this));
    ui->lineNoBanos->setValidator(new QIntValidator(this));
    ui->lineNoCuartos->setValidator(new QIntValidator(this));
    ui->lineNoPersonas->setValidator(new QIntValidator(this));
    ui->lineTarifaDiaria->setValidator(new QIntValidator(this));
    ui->lineTarifaSemanal->setValidator(new QIntValidator(this));
    ui->registroTel->setValidator(new QIntValidator(this));
    ui->registroNom_4->setValidator(new QDoubleValidator(this));
    ui->registroApM_4->setValidator(new QIntValidator(this));
    ui->stackedWidget->setCurrentIndex(0);
}

RentaFacil::~RentaFacil()
{
    delete ui;
}
void clearLayout(QLayout *layout) {
    QLayoutItem *item;
    while((item = layout->takeAt(0))) {
        if (item->layout()) {
            clearLayout(item->layout());
            delete item->layout();
        }
        if (item->widget()) {
           delete item->widget();
        }
        delete item;
    }
}

//se agregan las funciones de ver catalogo

//ejecuicon de la funcion de verCat_cliente
void RentaFacil::verCat_cliente()
{
    QSqlQuery catalogo,sacarfoto;
       QString catalogosql;
       QString titulo;
       QPixmap imagen;
       QIcon imagenreal;
       QByteArray foto1;
       QString nombreuser;
       QString llamarpro;


       catalogosql = "select titulo,nUsuarioP from Casa";
       catalogo.exec(catalogosql);
       int counterf = 0;
       int counterc = 0;



       while (catalogo.next()) {
           titulo = catalogo.value(0).toString();
           nombreuser=catalogo.value(1).toString();
           llamarpro="call informacioncat('"+nombreuser+"','"+titulo+"' );";
           sacarfoto.exec(llamarpro);
           sacarfoto.next();
           foto1=sacarfoto.value(13).toByteArray();
           imagen.loadFromData(foto1);
           QIcon foto2(imagen);


           if(imagen.isNull())
           {

           }
           else
           {
           QPushButton *h = new QPushButton();
           h->setAccessibleName(titulo);
           ui->catalogoCliente->addWidget(h , counterf, counterc, 1, 1);
           QSignalMapper *mapper=new QSignalMapper(this);
           connect(h,SIGNAL(clicked(bool)),mapper,SLOT(map()));
           mapper->setMapping(h,titulo);
           connect(mapper,SIGNAL(mapped(QString)),this,SLOT(darEspecificacion(QString)));
           h->setFixedSize(203, 100);
           h->setIcon(foto2);
           h->setIconSize(QSize(203,100));
           h->setStyleSheet("background-color: rgba(255,255,255,0);");
          // QLabel *label = new QLabel;
          // label->setText(titulo);
          // label->setFixedSize(203, 20);
           QTextEdit *label1=new QTextEdit;
           label1->setText(titulo);
           label1->setMaximumWidth(203);
           label1->setMaximumHeight(50);
           label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
           ui->catalogoCliente->addWidget(label1, counterf + 1, counterc, 1, 1);
           counterc++;
            }

           if (counterc == 3){
               counterf= counterf + 2;
               counterc = 0;
           }
       }


}

//ejecucuon de la funcioon ver_catalogo sin sesion
void RentaFacil::ver_catalogo()
{
    QSqlQuery catalogo,sacarfoto;
       QString catalogosql;
       QString titulo;
       QPixmap imagen;
       QIcon imagenreal;
       QByteArray foto1;
       QString nombreuser;
       QString llamarpro;


       catalogosql = "select titulo,nUsuarioP from Casa";
       catalogo.exec(catalogosql);
       int counterf = 0;
       int counterc = 0;



       while (catalogo.next()) {
           titulo = catalogo.value(0).toString();
           nombreuser=catalogo.value(1).toString();
           llamarpro="call informacioncat('"+nombreuser+"','"+titulo+"' );";
           sacarfoto.exec(llamarpro);
           sacarfoto.next();
           foto1=sacarfoto.value(13).toByteArray();
           imagen.loadFromData(foto1);
           QIcon foto2(imagen);


           if(imagen.isNull())
           {

           }
           else
           {
           QPushButton *h = new QPushButton();
           h->setAccessibleName(titulo);
           ui->layout->addWidget(h , counterf, counterc, 1, 1);
           QSignalMapper *mapper=new QSignalMapper(this);
           connect(h,SIGNAL(clicked(bool)),mapper,SLOT(map()));
           mapper->setMapping(h,titulo);
           connect(mapper,SIGNAL(mapped(QString)),this,SLOT(darEspecificacion(QString)));
           h->setFixedSize(203, 100);
           h->setIcon(foto2);
           h->setIconSize(QSize(203,100));
           h->setStyleSheet("background-color: rgba(255,255,255,0);");
          // QLabel *label = new QLabel;
          // label->setText(titulo);
          // label->setFixedSize(203, 20);
           QTextEdit *label1=new QTextEdit;
           label1->setText(titulo);
           label1->setMaximumWidth(203);
           label1->setMaximumHeight(50);
           label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
           ui->layout->addWidget(label1, counterf + 1, counterc, 1, 1);
           counterc++;
            }

           if (counterc == 3){
               counterf= counterf + 2;
               counterc = 0;
           }
       }


}






void RentaFacil::on_btnCreaCuenta_clicked()
{
    QString nombre = ui->registroNom->text();
    QString aPaterno = ui->registroApP->text();
    QString aMaterno = ui->registroApM->text();
    QString telefono = ui->registroTel->text();
    QString usuario = ui->registroUsuario->text();
    QString contra = ui->registroPass->text();
    QString nacimiento = ui->dateEdit_2->text();

    usuarioRegistro = usuario;

    qDebug()<<usuarioRegistro;



    int date = (ui->dateEdit_2->date().currentDate().year())-ui->dateEdit_2->date().year();


    QSqlQuery query;
    QSqlQuery query2;
    QString sql;
    QString sql2;


    if(nombre == "" || aPaterno == "" || aMaterno == "" || telefono == "" || usuario == "" || contra == "" || nacimiento == ""){
        QMessageBox messageBox(QMessageBox::Warning,
                                 tr("Critical Error"), tr("Por favor, llene todos los campos."), QMessageBox::Yes);

         messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

         if (messageBox.exec() == QMessageBox::Yes){

          }

    }else {
        if(ui->radioButton->isChecked()==true){
            tipoUsuarioRegistro = "Cliente";
            if( date >= 18){
                sql = "select nombreUsuario from cliente where nombreUsuario = '"+usuario+"';";
                int contador = 0;
                query.exec(sql);

                while (query.next()) {
                    contador++;
                }

                if(contador > 0){
                    QMessageBox messageBox(QMessageBox::Warning,
                                             tr("Critical Error"), tr("Este usuario ya existe"), QMessageBox::Yes);

                     messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

                     if (messageBox.exec() == QMessageBox::Yes){

                      }
                }
                else if(contador ==  0) {
                    sql = "insert into cliente(nombre, aPaterno, aMaterno, telefono, fNacimiento, nombreUsuario, clave) values ("
                          "'"+nombre+"', '"+aPaterno+"', '"+aMaterno+"', '"+telefono+"', '"+nacimiento+"', '"+usuario+"', '"+contra+"');";

                     query.exec(sql);
                    ui->stackedWidget->setCurrentIndex(4);
                 }
            }

            else {

                QMessageBox messageBox(QMessageBox::Warning,
                                         tr("Critical Error"), tr("Eres menor de edad"), QMessageBox::Yes);

                 messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

                 if (messageBox.exec() == QMessageBox::Yes){
                         ui->registroNom->setText("");
                         ui->registroApP->setText("");
                         ui->registroApM->setText("");
                         ui->registroTel->setText("");
                         ui->registroUsuario->setText("");
                         ui->registroPass->setText("");
                  }

            }


        }
        else if (ui->radioButton_2->isChecked()==true) {
            tipoUsuarioRegistro = "Propietario";
            if( date >= 18){
                sql = "select nombreUsuario from propietario where nombreUsuario = '"+usuario+"';";
                int contador = 0;
                query.exec(sql);

                while (query.next()) {
                    contador++;
                }

                if(contador > 0){
                    QMessageBox messageBox(QMessageBox::Warning,
                                             tr("Critical Error"), tr("Este usuario ya existe"), QMessageBox::Yes);

                     messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

                     if (messageBox.exec() == QMessageBox::Yes){

                      }
                }
                else if(contador ==  0) {
                    qDebug()<<"lleguéeeeeeeee";
                    sql = "insert into propietario(nombre, aPaterno, aMaterno, telefono, fNacimiento, nombreUsuario, clave) values ("
                          "'"+nombre+"', '"+aPaterno+"', '"+aMaterno+"', '"+telefono+"', '"+nacimiento+"', '"+usuario+"', '"+contra+"');";

                    qDebug()<<sql;
                    query.exec(sql);
                    ui->stackedWidget->setCurrentIndex(4);
                 }
            }

            else {

                QMessageBox messageBox(QMessageBox::Warning,
                                         tr("Critical Error"), tr("Eres menor de edad"), QMessageBox::Yes);

                 messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

                 if (messageBox.exec() == QMessageBox::Yes){
                         ui->registroNom->setText("");
                         ui->registroApP->setText("");
                         ui->registroApM->setText("");
                         ui->registroTel->setText("");
                         ui->registroUsuario->setText("");
                         ui->registroPass->setText("");
                  }

            }


        }
        else {
            QMessageBox messageBox(QMessageBox::Warning,
                                     tr("Critical Error"), tr("Por favor selecciona un tipo de usuario"), QMessageBox::Yes);

             messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

             if (messageBox.exec() == QMessageBox::Yes){

              }
        }

     qDebug()<<tipoUsuarioRegistro;
     qDebug()<<usuarioRegistro;


    }






}

void RentaFacil::on_btnRefIniSes_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->loginNom->clear();
    ui->loginPass->clear();
}


void RentaFacil::on_btnback_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void RentaFacil::on_btnLoginRegistrate_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void RentaFacil::on_btnLogoutAdmin_clicked()
{
    int numeroColumnas = ui->solicitudesTableWidget->rowCount();
                    QList<int> numeros;
                    for(int i=1; i<=numeroColumnas; i++){
                      numeros.append(i);
                      ui->solicitudesTableWidget->removeRow(numeros.value(i));
                    }

    ui->stackedWidget->setCurrentIndex(0);
    ver_catalogo();
}

/*---- Ofertar Casa ----*/
void RentaFacil::on_btnNextOffer_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);
}

void RentaFacil::on_btnBackOffer_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);
}

void RentaFacil::on_btnRegistrarCasa_clicked()
{
    QString titulo=ui->lineTitulo->text();
    QString ubicacion=ui->lineUbicacion->text();
    QString cp=ui->lineCP->text();
    QString estado=ui->comboBoxEstados->currentText();
    QString municipio=ui->comboBoxMunicipios->currentText();
    QString banios=ui->lineNoBanos->text();
    QString diario=ui->lineTarifaDiaria->text();
    QString semana=ui->lineTarifaSemanal->text();
    QString personas=ui->lineNoPersonas->text();
    QString cuartos=ui->lineNoCuartos->text();
    QString sianimal="1";
    QString noanimal="0";
    QString descripcion=ui->textEdit->toPlainText();



    QString Buscarmuni;
    Buscarmuni="select *from Municipio where nombre='"+municipio+"' ";
    QSqlQuery idbus;
    idbus.prepare(Buscarmuni);
    idbus.exec();
    idbus.next();
    QString idmun=idbus.value(0).toString();

    QString insertdir;
    insertdir="insert into Direccion(domicilio,cp,idMunicipio)values('"+ubicacion+"','"+cp+"','"+idmun+"');  ";
    QSqlQuery insert1;
    insert1.prepare(insertdir);
    insert1.exec();



    if(ui->radioSi_4->isChecked())
    {
        QString idd;

        //aqui busco el id de la direccion
        QString iddir;
        iddir="select id from Direccion where domicilio='"+ubicacion+"'  ;  ";
        QSqlQuery insert2;
        insert2.prepare(iddir);
        insert2.exec();

        while ( insert2.next()){
        idd=insert2.value(0).toString();
        qDebug()<<idd;
        }


        QString insertcasa;
        insertcasa="insert into Casa(numeroCuartos,numeroBanios,numeroPersonas,animales,descripcion,titulo,tarifaSemanal,tarifaDiaria,statusc,idDireccion,nUsuarioP)"
                    " values("+cuartos+","+banios+" ,"+personas+" ,"+sianimal+" ,'"+descripcion+"' ,'"+titulo+"' ,'"+semana+"' ,'"+diario+"' ,'0' ,'"+idd+"','"+user+"' ); " ;

         qDebug()<<insertcasa;
        QSqlQuery insertcasa1;
        insertcasa1.prepare(insertcasa);
        insertcasa1.exec();

        QString idcasa;
        idcasa="select *from Casa where titulo='"+titulo+"' and nUsuarioP='"+user+"' ; ";
        QSqlQuery idbuscasa;
        idbuscasa.prepare(idcasa);
        idbuscasa.exec();
        idbuscasa.next();

        QString idCasa1=idbuscasa.value(0).toString();
        qDebug()<<idCasa1;

        QString insertfoto;
        insertfoto="insert into fotocasa(ruta,idCasa,datosf)values('"+ruta1+"','"+idCasa1+"',:datos);   ";
        QSqlQuery insertfoto1;
        insertfoto1.prepare(insertfoto);
        insertfoto1.bindValue(":datos",imagen1);
        insertfoto1.exec();


    }
    else if(ui->radioNo_4->isChecked())
    {
        //aqui busco el id de la direccion
        QString iddir;
        iddir="select *from Direccion where domicilio='"+ubicacion+"'  ;  ";
        QSqlQuery insert2;
        insert2.prepare(iddir);
        insert2.exec();
        insert2.next();
        QString idd=insert2.value(0).toByteArray().constData();
        qDebug()<<idd;

        QString insertcasa;
        insertcasa="insert into Casa(numeroCuartos,numeroBanios,numeroPersonas,animales,descripcion,titulo,tarifaSemanal,tarifaDiaria,statusc,idDireccion,nUsuarioP)"
                    " values('"+cuartos+"','"+banios+"' ,'"+personas+"' ,'"+noanimal+"' ,'"+descripcion+"' ,'"+titulo+"' ,'"+semana+"' ,'"+diario+"' ,'0' ,'"+idd+"','"+user+"' ); " ;

         qDebug()<<insertcasa;
        QSqlQuery insertcasa1;
        insertcasa1.prepare(insertcasa);
        insertcasa1.exec();

        QString idcasa;
        idcasa="select *from Casa where titulo='"+titulo+"' and nUsuarioP='"+user+"' ; ";
        QSqlQuery idbuscasa;
        idbuscasa.prepare(idcasa);
        idbuscasa.exec();
        idbuscasa.next();

        QString idCasa1=idbuscasa.value(0).toString();
        qDebug()<<idCasa1;

        QString insertfoto;
        insertfoto="insert into fotocasa(ruta,idCasa,datosf)values('"+ruta1+"','"+idCasa1+"',:datos);   ";
        QSqlQuery insertfoto1;
        insertfoto1.prepare(insertfoto);
        insertfoto1.bindValue(":datos",imagen1);
        insertfoto1.exec();
        QMessageBox informacion;
        informacion.setWindowTitle("solicitud enviada");
        informacion.setText ("tu solicitud de guardo y envio correctamente");
        informacion.setStandardButtons( QMessageBox::Ok) ;
        informacion.setDefaultButton (QMessageBox ::Ok ) ;
        informacion.setButtonText( QMessageBox::Ok,"Aceptar");
        informacion.exec();

    }
    else
    {
        QMessageBox messageBox(QMessageBox::Warning,
                                 tr("Critical Error"), tr("selecciona el acceso a nimales"), QMessageBox::Yes);

         messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

         if (messageBox.exec() == QMessageBox::Yes){

          }
    }





ui->stackedWidget->setCurrentIndex(5);

verCasasPro();


}


//agregar imagen
void RentaFacil::on_btnAgregaImg_clicked()
{
 auto nombreArchivo = QFileDialog::getOpenFileName(this,"abrir imagen",QDir::rootPath(),"imagenes(*.png *.jpg *.jpeg);; cualquier archivo(*.*)");
 QString ruta=nombreArchivo;
 QFile archivo(ruta);
 if(!archivo.open(QIODevice::ReadOnly))
 {
     return;
 }
 QByteArray mostrar=archivo.readAll();
 QPixmap imag;
 imag.loadFromData(mostrar);
 ui->lblFoto_3->setPixmap(imag);

 ruta1=ruta;
 imagen1=mostrar;



}

/*---- Propietario ----*/
void RentaFacil::on_btnAddCasa_clicked()
{
    ui->stackedWidget->setCurrentIndex(6);

    //aqui limpio toda la interfaz:
    ui->lineTitulo->clear();
    ui->lineUbicacion->clear();
    ui->lineCP->clear();
    ui->comboBoxEstados->setCurrentIndex(0);
    ui->comboBoxMunicipios->setCurrentIndex(0);
    ui->lineNoBanos->clear();
    ui->lineNoCuartos->clear();
    ui->lineNoPersonas->clear();
    ui->lineTarifaDiaria->clear();
    ui->lineTarifaSemanal->clear();
    ui->textEdit->clear();
    ui->lblFoto_3->clear();


}

void RentaFacil::on_btnLogoutProp_clicked()
{

   clearLayout(ui->misCasasLayout);
   ui->stackedWidget->setCurrentIndex(0);
   ver_catalogo();
}
//registro de casa cancelado
void RentaFacil::on_btnCancelaRegistro_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


/*---------------------*/

/*---- Registro Cuenta----*/
    void RentaFacil::on_radioButton_2_clicked()
    {
        ui->radioButton_2->setEnabled(true);
    }

    //Pasa a ventana de cuenta bancaria
    void RentaFacil::on_btnContinuaReg_clicked()
    {
        ui->stackedWidget->setCurrentIndex(4);
    }

    void RentaFacil::on_radioClienteProp_clicked()
    {
        ui->stackedWidget->setCurrentIndex(2);
    }
    // ---- registro a iniciar sesión ----
        void RentaFacil::on_btnRegToIni_clicked()
        {
            ui->stackedWidget->setCurrentIndex(1);
            ui->loginNom->clear();
            ui->loginPass->clear();
        }

        void RentaFacil::on_btnRegToIni_3_clicked()
        {
            ui->stackedWidget->setCurrentIndex(1);
            ui->loginNom->clear();
            ui->loginPass->clear();
        }

        void RentaFacil::on_btnRegToIni_4_clicked()
        {
            ui->stackedWidget->setCurrentIndex(1);
            ui->loginNom->clear();
            ui->loginPass->clear();
        }

    // -----------------------------------

void RentaFacil::on_btnCrearCuentaPropietario_clicked()
{
    QString numero = ui->registroNom_4->text();
    QString expira = ui->dateEdit_3->text();
    QString codigo = ui->registroApM_4->text();
    QString banco = ui->comboBox_2->currentText();

    QSqlQuery query;
    QString sql;

    if(numero == "" || expira == "" || codigo == "" || banco == ""){
        QMessageBox messageBox(QMessageBox::Warning,
                                 tr("Critical Error"), tr("Algunos campod no han sido llenados aun."), QMessageBox::Yes);

         messageBox.setButtonText(QMessageBox::Yes, tr("Entiendo"));

         if (messageBox.exec() == QMessageBox::Yes){

          }
    }else {
        if(tipoUsuarioRegistro == "Cliente"){
            sql = "insert into cBancariaC (numero, fVencimiento, saldo, codigo, banco, idCliente) values ("
                  +numero+", '"+expira+"', 1000000, "+codigo+", '"+banco+"', '"+usuarioRegistro+"');";

            query.exec(sql);

            QMessageBox informacion;
            informacion.setWindowTitle("Usuario creado correctamente");
            informacion.setText ("tus datos se guardaron correctamente");
            informacion.setStandardButtons( QMessageBox::Ok) ;
            informacion.setDefaultButton (QMessageBox ::Ok ) ;
            informacion.setButtonText( QMessageBox::Ok,"Aceptar");
            informacion.exec();

            ui->stackedWidget->setCurrentIndex(0);

        }
        else if (tipoUsuarioRegistro == "Propietario") {
            sql = "insert into cBancariaP (numero, fVencimiento, saldo, codigo, banco, idPropietario) values ("
                  +numero+", '"+expira+"', 0, "+codigo+", '"+banco+"', '"+usuarioRegistro+"');";

            qDebug()<<sql;
            query.exec(sql);

            QMessageBox informacion;
            informacion.setWindowTitle("Usuario creado correctamente");
            informacion.setText ("tus datos se guardaron correctamente");
            informacion.setStandardButtons( QMessageBox::Ok) ;
            informacion.setDefaultButton (QMessageBox ::Ok ) ;
            informacion.setButtonText( QMessageBox::Ok,"Aceptar");
            informacion.exec();

            ui->stackedWidget->setCurrentIndex(0);
        }
    }


    ui->registroNom->clear();
    ui->registroApM->clear();
    ui->registroApP->clear();
    ui->registroTel->clear();
    ui->registroUsuario->clear();
    ui->registroPass->clear();
    ui->registroNom_4->clear();
    ui->registroApM_4->clear();
    ui->dateEdit->clear();
    ui->comboBox_2->clear();
    ui->dateEdit_3->clear();
}

/*------------------*/

//Administrador rechaza la solicitud de la casa
void RentaFacil::on_btnRechazar_clicked()
{
    QSqlQuery query;
    QString sql;
    QString calificacion = ui->comboBox->currentText();
    QString idCas;
    sql = "delete from fotocasa where idCasa = "+idCasaG+";";
    query.exec(sql);
    sql = "delete from casa where id = "+idCasaG+";";
    query.exec(sql);
    sql = "select idDireccion from casa where id = "+idCasaG+";";
    query.exec(sql);
    while (query.next()) {
        idCas = query.value(0).toString();
    }
    sql = "delete from direccion where id = "+idCas+";";
    query.exec(sql);

    int numeroColumnas = ui->solicitudesTableWidget->rowCount();
                    QList<int> numeros;
                    for(int i=1; i<=numeroColumnas; i++){
                      numeros.append(i);
                      ui->solicitudesTableWidget->removeRow(numeros.value(i));
                    }

    sql = "select * from solicitudes;";
    query.exec(sql);

    while(query.next()){
        QString propietario = query.value(0).toString();
        QString titulo = query.value(1).toString();
        QString estado = query.value(2).toString();
        QString municipio = query.value(3).toString();
        QString direccion = query.value(4).toString();

        ui->solicitudesTableWidget->insertRow(ui->solicitudesTableWidget->rowCount());
                int fila=ui->solicitudesTableWidget->rowCount()-1;

                ui->solicitudesTableWidget->setItem(fila, 0, new QTableWidgetItem(propietario));
                ui->solicitudesTableWidget->setItem(fila, 1, new QTableWidgetItem(titulo));
                ui->solicitudesTableWidget->setItem(fila, 2, new QTableWidgetItem(estado));
                ui->solicitudesTableWidget->setItem(fila, 3, new QTableWidgetItem(municipio));
                ui->solicitudesTableWidget->setItem(fila, 4, new QTableWidgetItem(direccion));

    }

    ui->stackedWidget->setCurrentIndex(8);
}
//Administrador acepta solicitud de la casa
void RentaFacil::on_btnAprobar_clicked()
{
    QSqlQuery query;
    QString sql;
    QString calificacion = ui->comboBox->currentText();
    sql = "update casa set statusc = 1, calificacion = "+calificacion+" where id = "+idCasaG+";";
    query.exec(sql);

    int numeroColumnas = ui->solicitudesTableWidget->rowCount();
                    QList<int> numeros;
                    for(int i=1; i<=numeroColumnas; i++){
                      numeros.append(i);
                      ui->solicitudesTableWidget->removeRow(numeros.value(i));
                    }

    sql = "select * from solicitudes;";
    query.exec(sql);

    while(query.next()){
        QString propietario = query.value(0).toString();
        QString titulo = query.value(1).toString();
        QString estado = query.value(2).toString();
        QString municipio = query.value(3).toString();
        QString direccion = query.value(4).toString();

        ui->solicitudesTableWidget->insertRow(ui->solicitudesTableWidget->rowCount());
                int fila=ui->solicitudesTableWidget->rowCount()-1;

                ui->solicitudesTableWidget->setItem(fila, 0, new QTableWidgetItem(propietario));
                ui->solicitudesTableWidget->setItem(fila, 1, new QTableWidgetItem(titulo));
                ui->solicitudesTableWidget->setItem(fila, 2, new QTableWidgetItem(estado));
                ui->solicitudesTableWidget->setItem(fila, 3, new QTableWidgetItem(municipio));
                ui->solicitudesTableWidget->setItem(fila, 4, new QTableWidgetItem(direccion));

    }



    ui->stackedWidget->setCurrentIndex(11);
}

void RentaFacil::on_btnRefReg_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void RentaFacil::on_pushButton_2_clicked()
{
    currentUsuario = ui->loginNom->text();
    QString usuario = ui->loginNom->text();
    QString clave = ui->loginPass->text();

    QString clavev;
    QSqlQuery query;
    QString sql;

    int contador = 0;
    if(ui->iniciarClienteRB->isChecked() == true){
        sql = "select clave from cliente where nombreUsuario = '"+usuario+"';";
        query.exec(sql);

        while (query.next()) {
            contador++;
            clavev = query.value(0).toString();
        }

        if(contador == 0){
            QMessageBox informacion;
            informacion.setWindowTitle("No existe el usuario");
            informacion.setText ("El usuario ingresado no ha sido registrado");
            informacion.setStandardButtons( QMessageBox::Ok) ;
            informacion.setDefaultButton (QMessageBox ::Ok ) ;
            informacion.setButtonText( QMessageBox::Ok,"Aceptar");
            informacion.exec();
        }
        else if (contador == 1) {
            if(clave == clavev){
                ui->stackedWidget->setCurrentIndex(13);
                user=ui->loginNom->text();
                verCat_cliente();            }
            else {
                QMessageBox informacion;
                informacion.setWindowTitle("Contraseña incorrecta");
                informacion.setText ("La contraseña es incorrecta");
                informacion.setStandardButtons( QMessageBox::Ok) ;
                informacion.setDefaultButton (QMessageBox ::Ok ) ;
                informacion.setButtonText( QMessageBox::Ok,"Aceptar");
                informacion.exec();
            }
        }



    }
    else if (ui->iniciarPropietarioRB->isChecked() == true) {
        QSqlQuery catalogo;
        QString catalogosql;
        QString titulo;
        int statusc;
        catalogosql = "select titulo, statusc from Casa where nUsuarioP = '"+currentUsuario+"';";
        catalogo.exec(catalogosql);
        qDebug() << catalogosql;

        QString buscarfoto;
        QSqlQuery catcasa;
        QPixmap imagen;
        QIcon imagenreal;
        QByteArray foto1;
        int counterf = 0;
        int counterc = 0;
        while (catalogo.next()) {
            titulo = catalogo.value(0).toString();
            statusc = catalogo.value(1).toInt();

            if(statusc == 0){
                buscarfoto="call informacion('"+currentUsuario+"','"+titulo+"' );";
                catcasa.exec(buscarfoto);
                catcasa.next();
                foto1=catcasa.value(13).toByteArray();
                imagen.loadFromData(foto1);
                QIcon foto2(imagen);


                QPushButton *h = new QPushButton();
                ui->misCasasLayout->addWidget(h , counterf, counterc, 1, 1);
                h->setFixedSize(203, 100);
                h->setIcon(foto2);
                h->setEnabled(false);
                h->setIconSize(QSize(203,100));
                h->setStyleSheet("background-color: rgba(255,255,255,0);");
                //QLabel *label = new QLabel;
                //label->setText(titulo);
                //label->setFixedSize(203, 20);
                QTextEdit *label1=new QTextEdit;
                label1->setText(titulo);
                label1->setMaximumWidth(203);
                label1->setMaximumHeight(50);
                label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
                ui->misCasasLayout->addWidget(label1, counterf + 1, counterc, 1, 1);
                counterc++;

            }else if (statusc == 1) {

                //se agrego todo esto
                buscarfoto="call informacioncat('"+currentUsuario+"','"+titulo+"' );";
                catcasa.exec(buscarfoto);
                catcasa.next();
                foto1=catcasa.value(13).toByteArray();
                imagen.loadFromData(foto1);
                QIcon foto2(imagen);



                QPushButton *h = new QPushButton();
                ui->misCasasLayout->addWidget(h , counterf, counterc, 1, 1);
                h->setFixedSize(203, 100);
                //se agrego tambien
                h->setIcon(foto2);
                h->setIconSize(QSize(203,100));
                h->setStyleSheet("background-color: rgba(255,255,255,0);");
                QSignalMapper *mensaje=new QSignalMapper(this);
                connect(h,SIGNAL(clicked(bool)),mensaje,SLOT(map()));
                mensaje->setMapping(h,titulo);
                connect(mensaje,SIGNAL(mapped(QString)),this,SLOT(modificar(QString)));

                //QLabel *label = new QLabel;
               // label->setText(titulo);
               // label->setFixedSize(203, 20);
                QTextEdit *label1=new QTextEdit;
                label1->setText(titulo);
                label1->setMaximumWidth(203);
                label1->setMaximumHeight(50);
                label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
                ui->misCasasLayout->addWidget(label1, counterf + 1, counterc, 1, 1);
                counterc++;
            }


            if (counterc == 3){
                counterf= counterf + 2;
                counterc = 0;
            }
        }

        sql = "select clave from propietario where nombreUsuario = '"+usuario+"';";
        query.exec(sql);

        while (query.next()) {
            contador++;
            clavev = query.value(0).toString();
        }

        if(contador == 0){
            QMessageBox informacion;
            informacion.setWindowTitle("No existe el usuario");
            informacion.setText ("El usuario ingresado no ha sido registrado");
            informacion.setStandardButtons( QMessageBox::Ok) ;
            informacion.setDefaultButton (QMessageBox ::Ok ) ;
            informacion.setButtonText( QMessageBox::Ok,"Aceptar");
            informacion.exec();
        }
        else if (contador == 1) {
            if(clave == clavev){
                ui->stackedWidget->setCurrentIndex(5);
                user=usuario;
            }
            else {
                QMessageBox informacion;
                informacion.setWindowTitle("Contraseña incorrecta");
                informacion.setText ("La contraseña es incorrecta");
                informacion.setStandardButtons( QMessageBox::Ok) ;
                informacion.setDefaultButton (QMessageBox ::Ok ) ;
                informacion.setButtonText( QMessageBox::Ok,"Aceptar");
                informacion.exec();
            }
        }

    }else if (ui->iniciarAdministradorRB->isChecked() == true) {

        if(usuario == "Admin" && clave == "admin1234"){
        sql = "select * from solicitudes;";
        query.exec(sql);

        while(query.next()){
            QString propietario = query.value(0).toString();
            QString titulo = query.value(1).toString();
            QString estado = query.value(2).toString();
            QString municipio = query.value(3).toString();
            QString direccion = query.value(4).toString();

            ui->solicitudesTableWidget->insertRow(ui->solicitudesTableWidget->rowCount());
                    int fila=ui->solicitudesTableWidget->rowCount()-1;

                    ui->solicitudesTableWidget->setItem(fila, 0, new QTableWidgetItem(propietario));
                    ui->solicitudesTableWidget->setItem(fila, 1, new QTableWidgetItem(titulo));
                    ui->solicitudesTableWidget->setItem(fila, 2, new QTableWidgetItem(estado));
                    ui->solicitudesTableWidget->setItem(fila, 3, new QTableWidgetItem(municipio));
                    ui->solicitudesTableWidget->setItem(fila, 4, new QTableWidgetItem(direccion));
        }
            ui->stackedWidget->setCurrentIndex(11);
        }
        else {
            QMessageBox informacion;
            informacion.setWindowTitle("Contraseña o Usuario incorrectos");
            informacion.setText ("Contraseña o Usuario incorrectos");
            informacion.setStandardButtons( QMessageBox::Ok) ;
            informacion.setDefaultButton (QMessageBox ::Ok ) ;
            informacion.setButtonText( QMessageBox::Ok,"Aceptar");
            informacion.exec();
        }
    }
}



//funcionde modificar
void RentaFacil::modificar(QString titulo)
{
    ui->stackedWidget->setCurrentIndex(8);
    ui->lineTitulo_3->setText(titulo);


    QString buscar;
    buscar="select nUsuarioP,descripcion from casa where titulo='"+titulo+"'; ";
    QSqlQuery getuser;
    getuser.exec(buscar);
    getuser.next();
    QString user;
    user=getuser.value(0).toString();
    QString datosf;
    datosf="call informacioncat('"+user+"','"+titulo+"')";
    QSqlQuery datosfull;
    datosfull.exec(datosf);
    datosfull.next();

    QString person;
    person="select nombre, aPaterno,telefono from propietario where nombreUsuario='"+user+"'; ";
    QSqlQuery personbus;
    personbus.exec(person);
    personbus.next();
    QString nombre,ape,nombrec;
    nombre=personbus.value(0).toString();
    ape=personbus.value(1).toString();
    nombrec=nombre + " "+ape;
    QByteArray foto1;
    QPixmap imagen;


    foto1=datosfull.value(13).toByteArray();
    imagen.loadFromData(foto1);
    QIcon fotoo(imagen);

    ui->lineUbicacionModifica->setText(datosfull.value(11).toString());
    ui->lblEstadoModifica->setText(datosfull.value(9).toString());
    ui->lblMunicipioModifica->setText(datosfull.value(10).toString());
    ui->lineCPModifica->setText(datosfull.value(12).toString());
    ui->lineNoBanos_3->setText(datosfull.value(4).toString());
    ui->lineNoCuartos_3->setText(datosfull.value(3).toString());
    ui->lineNoPersonas_3->setText(datosfull.value(2).toString());
    ui->lineTarifaDiaria_3->setText(datosfull.value(6).toString());
    ui->lineTarifaSemanal_3->setText(datosfull.value(7).toString());
    ui->textEdit_3->setText(getuser.value(1).toString());
    ui->btnAgregaImgs_2->setIcon(fotoo);




}

void RentaFacil::on_comboBoxEstados_currentTextChanged(const QString &arg1)
{
    ui->comboBoxMunicipios->clear();
    QString municipio=ui->comboBoxEstados->currentText();
       QSqlQuery buscaEs;
       QString idEstado;
       idEstado="select id from Estado where nombre='"+municipio+"'  ";
       buscaEs.prepare(idEstado);
       buscaEs.exec();
       buscaEs.next();
       QString Estado1=buscaEs.value(0).toString();
       QString nombreEs;
       nombreEs="select *from Municipio where estado_id='"+Estado1+"' ";
       QSqlQuery nuevo;
       nuevo.prepare(nombreEs);
       nuevo.exec();

       while(nuevo.next())
       {
           ui->comboBoxMunicipios->addItem(nuevo.value(3).toString());
       }
}

void RentaFacil::on_solicitudesTableWidget_cellDoubleClicked(int row, int column)
{

    QString usuario  = ui->solicitudesTableWidget->item(row,0)->text();
    QString titulo = ui->solicitudesTableWidget->item(row, 1)->text();

    QString numeroPersonas, numeroCuartos, numeroBanios, animales, tarifaD, tarifaS, descripcion, domicilio, cp, estado, municipio;
    QByteArray foto;


    QSqlQuery query;
    QString sql;

    QPixmap pixmap;
    sql = "call informacion ('"+usuario+"', '"+titulo+"');";
    query.exec(sql);

    while(query.next()){
        numeroPersonas = query.value(2).toString();
        numeroCuartos = query.value(3).toString();
        numeroBanios = query.value(4).toString();
        animales = query.value(5).toString();
        tarifaD = query.value(6).toString();
        tarifaS = query.value(7).toString();
        descripcion = query.value(8).toString();
        estado = query.value(9).toString();
        municipio = query.value(10).toString();
        domicilio = query.value(11).toString();
        cp = query.value(12).toString();
        foto = query.value(13).toByteArray();
    }

    pixmap.loadFromData(foto);



    ui->lblTituloPropiedad->setText(titulo);
    ui->lblPersonasAdmitidas->setText(numeroPersonas);
    ui->lblNumCuartos->setText(numeroCuartos);
    ui->lblBanios->setText(numeroBanios);
    ui->lblAnimales->setText(animales);
    ui->lblTarifaDia->setText(tarifaD);
    ui->lblTarifaSem->setText(tarifaS);
    ui->PTDescripcion->setPlainText(descripcion);
    ui->lblDireccion->setText(domicilio);
    ui->lblCP->setText(cp);
    ui->lblEstado->setText(estado);
    ui->lblMunicipio->setText(municipio);
    ui->lblFoto_2->setPixmap(pixmap);


    sql = "select id from casa where titulo = '"+titulo+"' and nUsuarioP = '"+usuario+"';";
    query.exec(sql);
    while(query.next()){
        idCasaG = query.value(0).toString();
    }

    ui->stackedWidget->setCurrentIndex(12);
}

void RentaFacil::on_btnback_Admin_clicked()
{
    ui->stackedWidget->setCurrentIndex(11);
}


void RentaFacil::on_btnLogoutCliente_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void RentaFacil::on_btnbackRegistro_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void RentaFacil::darEspecificacion(QString clave){




    QString buscar;
    buscar="select nUsuarioP from casa where titulo='"+clave+"'; ";
    QSqlQuery getuser;
    getuser.exec(buscar);
    getuser.next();
    QString user;
    user=getuser.value(0).toString();
    QString datosf;
    datosf="call informacioncat('"+user+"','"+clave+"')";
    QSqlQuery datosfull;
    datosfull.exec(datosf);
    datosfull.next();

    QString person;
    person="select nombre, aPaterno,telefono from propietario where nombreUsuario='"+user+"'; ";
    QSqlQuery personbus;
    personbus.exec(person);
    personbus.next();
    QString nombre,ape,nombrec;
    nombre=personbus.value(0).toString();
    ape=personbus.value(1).toString();
    nombrec=nombre + " "+ape;
    QByteArray foto1;
    QPixmap imagen;


    foto1=datosfull.value(13).toByteArray();
    imagen.loadFromData(foto1);

    ui->stackedWidget->setCurrentIndex(14);

    ui->lblNombrePropietario->setText(nombrec);
    ui->lblTelefono->setText(personbus.value(2).toString());

    ui->lblTituloCasa1->setText(clave);
    ui->label_60->setText(datosfull.value(2).toString());
    ui->lblNumHabitaciones->setText(datosfull.value(3).toString());
    if(datosfull.value(5).toString()=="1")
    {
        ui->label_66->setText("se aceptan");
    }
    else
    {
    ui->label_66->setText("no se aceptan");
    }
    ui->lblCuotaDiaria->setText("$: "+datosfull.value(6).toString()+" MXN.");
    ui->lblCuotaSemanal->setText("$: "+datosfull.value(7).toString()+" MXN.");
    ui->lblEstado_2->setText(datosfull.value(9).toString());
    ui->lblMunicipio_2->setText(datosfull.value(10).toString());
    ui->lblDireccionCasa->setText(datosfull.value(11).toString());
    ui->lblCPOST->setText(datosfull.value(12).toString());
    ui->label_11->setPixmap(imagen);


    //aqui se ejecuta la busqueda del album

    QString direc;
    direc=ui->lblDireccionCasa->text();
    qDebug()<<direc;

    QString buscarid;
    buscarid="select id from Direccion where domicilio='"+direc+"'; ";
    QSqlQuery busid;
    busid.exec(buscarid);
    busid.next();

    QString iddir;
    iddir=busid.value(0).toString();

    QSqlQuery idcasa;
    QString idcasa1;
    idcasa1="select id from Casa where idDireccion='"+iddir+"'; ";
    idcasa.exec(idcasa1);
    idcasa.next();

    QString idcasa2;
    idcasa2=idcasa.value(0).toString();

    QString fotocasa1;
    QSqlQuery bus2;
    fotocasa1="select datosf,id from fotocasa where idCasa='"+idcasa2+"'; ";
    bus2.exec(fotocasa1);
    album=bus2;








}

void RentaFacil::on_btnAgregaImgs_clicked()
{


    QString buscarid;
    buscarid="select id from Direccion where domicilio='"+ui->lineUbicacionModifica->text()+"'; ";
    QSqlQuery busid;
    busid.exec(buscarid);
    busid.next();

    QString iddir;
    iddir=busid.value(0).toString();

    QSqlQuery idcasa;
    QString idcasa1;
    idcasa1="select id from Casa where idDireccion='"+iddir+"'; ";
    idcasa.exec(idcasa1);
    idcasa.next();

    QString idcasa2;
    idcasa2=idcasa.value(0).toString();

    QSqlQuery fotocasa;
    QString fotocasa1;
    fotocasa1="select datosf,id from fotocasa where idCasa='"+idcasa2+"'; ";
    fotocasa.exec(fotocasa1);
    QString idfotoc;


    QByteArray foto1;
    QPixmap imagen;
    int counterf=0;
    int counterc=0;
    while(fotocasa.next())
    {

        foto1=fotocasa.value(0).toByteArray();
        idfotoc=fotocasa.value(1).toString();
        imagen.loadFromData(foto1);
        QIcon foto2(imagen);

        QPushButton *h = new QPushButton();

        ui->gridLayout_5->addWidget(h , counterf, counterc, 1, 1);

        h->setFixedSize(100, 100);
        h->setIcon(foto2);
        h->setIconSize(QSize(100,100));
        h->setStyleSheet("background-color: rgba(255,255,255,0);");
        QSignalMapper *mapper=new QSignalMapper(this);
        connect(h,SIGNAL(clicked(bool)),mapper,SLOT(map()));
        mapper->setMapping(h,idfotoc);
        connect(mapper,SIGNAL(mapped(QString)),this,SLOT(eliminarfoto(QString)));

        counterc++;

        if (counterc == 3){
            counterf= counterf + 2;
            counterc = 0;
        }
    }



    ui->stackedWidget->setCurrentIndex(10);

}

void RentaFacil::on_btnAgregaImgs_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(10);
}

void RentaFacil::on_btnListoImg_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}

void RentaFacil::on_btnCancelaImg_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}
//version de joshua
//slot de dar especificaciones:




void RentaFacil::verCasasPro()
{
    QSqlQuery catalogo;
    QString catalogosql;
    QString titulo;
    int statusc;
    catalogosql = "select titulo, statusc from Casa where nUsuarioP = '"+currentUsuario+"';";
    catalogo.exec(catalogosql);
    qDebug() << catalogosql;


    //aqui se crea la funcion para que salgan las casa del propietario

    QString buscarfoto;
    QSqlQuery catcasa;
    QPixmap imagen;
    QIcon imagenreal;
    QByteArray foto1;
    int counterf = 0;
    int counterc = 0;
    while (catalogo.next()) {
        titulo = catalogo.value(0).toString();
        statusc = catalogo.value(1).toInt();

        if(statusc == 0){
            buscarfoto="call informacion('"+currentUsuario+"','"+titulo+"' );";
            catcasa.exec(buscarfoto);
            catcasa.next();
            foto1=catcasa.value(13).toByteArray();
            imagen.loadFromData(foto1);
            QIcon foto2(imagen);


            QPushButton *h = new QPushButton();
            ui->misCasasLayout->addWidget(h , counterf, counterc, 1, 1);
            h->setFixedSize(203, 100);
            h->setIcon(foto2);
            h->setEnabled(false);
            h->setIconSize(QSize(203,100));
            h->setStyleSheet("background-color: rgba(255,255,255,0);");
           // QLabel *label = new QLabel;
            //label->setText(titulo);
           // label->setFixedSize(203, 20);
            QTextEdit *label1=new QTextEdit;
            label1->setText(titulo);
            label1->setMaximumWidth(203);
            label1->setMaximumHeight(50);
            label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
            ui->misCasasLayout->addWidget(label1, counterf + 1, counterc, 1, 1);
            counterc++;

        }else if (statusc == 1) {

            //se agrego todo esto
            buscarfoto="call informacioncat('"+currentUsuario+"','"+titulo+"' );";
            catcasa.exec(buscarfoto);
            catcasa.next();
            foto1=catcasa.value(13).toByteArray();
            imagen.loadFromData(foto1);
            QIcon foto2(imagen);



            QPushButton *h = new QPushButton();
            ui->misCasasLayout->addWidget(h , counterf, counterc, 1, 1);
            h->setFixedSize(203, 100);
            //se agrego tambien
            h->setIcon(foto2);
            h->setIconSize(QSize(203,100));
            h->setStyleSheet("background-color: rgba(255,255,255,0);");
            QSignalMapper *mensaje=new QSignalMapper(this);
            connect(h,SIGNAL(clicked(bool)),mensaje,SLOT(map()));
            mensaje->setMapping(h,titulo);
            connect(mensaje,SIGNAL(mapped(QString)),this,SLOT(modificar(QString)));
          //  QLabel *label = new QLabel;
          //  label->setText(titulo);
          //  label->setFixedSize(203, 20);
            QTextEdit *label1=new QTextEdit;
            label1->setText(titulo);
            label1->setMaximumWidth(203);
            label1->setMaximumHeight(50);
            label1->setStyleSheet("QTextEdit {background-color: rgba(255,255,255,0); border:none ;}");
            ui->misCasasLayout->addWidget(label1, counterf + 1, counterc, 1, 1);
            counterc++;
        }


        if (counterc == 3){
            counterf= counterf + 2;
            counterc = 0;
        }
    }


}




void RentaFacil::on_btnback_2_clicked()
{
    //aqui es una copia
    if(ui->iniciarClienteRB->isChecked())
    {
     ui->stackedWidget->setCurrentIndex(10);
    }
    else
    {
    ui->stackedWidget->setCurrentIndex(0);
    }
}

void RentaFacil::on_btnNextOffer_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}

void RentaFacil::on_btnBackOffer_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(8);
}

void RentaFacil::on_btnRegistrarCasa_2_clicked()
{
    //falta el update pero si ya esta ignora
    QString titu=ui->lineTitulo_3->text();
    QString banos=ui->lineNoBanos_3->text();
    QString person=ui->lineNoPersonas_3->text();
    QString cuarto=ui->lineNoCuartos_3->text();
    QString tarD=ui->lineTarifaDiaria_3->text();
    QString tarS=ui->lineTarifaSemanal_3->text();
    QString aniS="1";
    QString aniN="0";
    QString desc=ui->textEdit_3->toPlainText();
    QString idcasaU;

    QString buscarid;
    buscarid="select id from Direccion where domicilio='"+ui->lineUbicacionModifica->text()+"'; ";
    QSqlQuery busid;
    busid.exec(buscarid);
    busid.next();

    QString iddir;
    iddir=busid.value(0).toString();

    QSqlQuery idcasa;
    QString idcasa1;
    idcasa1="select id from Casa where idDireccion='"+iddir+"'; ";
    idcasa.exec(idcasa1);
    idcasa.next();


    idcasaU=idcasa.value(0).toString();
if(ui->radioNo_6->isChecked()==0 && ui->radioSi_6->isChecked()==0 )
{
    QMessageBox info;
             info.setWindowTitle("Informacion");
             info.setText("Debes selecionar el acceso de animales");
             info.setStandardButtons(QMessageBox::Ok);
             info.setDefaultButton(QMessageBox::Ok);
             info.setButtonText(QMessageBox::Ok,"Aceptar");
             info.exec();
}
else
{



    if(ui->radioSi_6->isChecked()==1)
    {
        QMessageBox msgBox(QMessageBox::Question,"Alerta","¿Estas seguro?",QMessageBox::Yes|QMessageBox::No);
            msgBox.setButtonText(QMessageBox::Yes,"Si");
            msgBox.setButtonText(QMessageBox::No,"No");
            if(msgBox.exec()==QMessageBox::Yes){
                QString update1;
                update1="update casa set titulo='"+titu+"', numeroBanios='"+banos+"',numeroPersonas='"+person+"',numeroCuartos='"+cuarto+"',tarifaDiaria='"+tarD+"',tarifaSemanal='"+tarS+"',animales='"+aniS+"',descripcion='"+desc+"' where nUsuarioP='"+currentUsuario+"' and id='"+idcasaU+"';  ";
                QSqlQuery upd;
                upd.exec(update1);

                QMessageBox info;
                         info.setWindowTitle("Informacion");
                         info.setText("se ejecuto con exito");
                         info.setStandardButtons(QMessageBox::Ok);
                         info.setDefaultButton(QMessageBox::Ok);
                         info.setButtonText(QMessageBox::Ok,"Aceptar");
                         info.exec();

                 ui->stackedWidget->setCurrentIndex(5);
                verCasasPro();
            }
            else{



            }


    }
    else if(ui->radioNo_6->isChecked()==1)
    {
        QMessageBox msgBox(QMessageBox::Question,"Alerta","¿Esta seguro?",QMessageBox::Yes|QMessageBox::No);
            msgBox.setButtonText(QMessageBox::Yes,"Si");
            msgBox.setButtonText(QMessageBox::No,"No");
            if(msgBox.exec()==QMessageBox::Yes){
                QString update1;
                update1="update casa set titulo='"+titu+"', numeroBanios='"+banos+"',numeroPersonas='"+person+"',numeroCuartos='"+cuarto+"',tarifaDiaria='"+tarD+"',tarifaSemanal='"+tarS+"',animales='"+aniN+"',descripcion='"+desc+"' where nUsuarioP='"+currentUsuario+"' and id='"+idcasaU+"';  ";
                QSqlQuery upd;
                upd.exec(update1);

                QMessageBox info;
                         info.setWindowTitle("Informacion");
                         info.setText("Se ejecuto con exito");
                         info.setStandardButtons(QMessageBox::Ok);
                         info.setDefaultButton(QMessageBox::Ok);
                         info.setButtonText(QMessageBox::Ok,"Aceptar");
                         info.exec();

                 ui->stackedWidget->setCurrentIndex(5);
                verCasasPro();
            }
            else{



            }

    }


 }


}

void RentaFacil::on_btnCancelaRegistro_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
    verCasasPro();
}

void RentaFacil::on_agregarfoto_clicked()
{
    auto nombreArchivo = QFileDialog::getOpenFileName(this,"abrir imagen",QDir::rootPath(),"imagenes(*.png *.jpg *.jpeg);; cualquier archivo(*.*)");
    QString ruta=nombreArchivo;
    QFile archivo(ruta);
    if(!archivo.open(QIODevice::ReadOnly))
    {
        return;
    }
    QByteArray mostrar=archivo.readAll();
    QPixmap imag;
    imag.loadFromData(mostrar);
    ui->label_108->setPixmap(imag);
    rutanueva=ruta;
    imagen2=mostrar;
}

void RentaFacil::on_guardarfoto_clicked()
{
    QString buscarid;
    buscarid="select id from Direccion where domicilio='"+ui->lineUbicacionModifica->text()+"'; ";
    QSqlQuery busid;
    busid.exec(buscarid);
    busid.next();

    QString iddir;
    iddir=busid.value(0).toString();

    QSqlQuery idcasa;
    QString idcasa1;
    idcasa1="select id from Casa where idDireccion='"+iddir+"'; ";
    idcasa.exec(idcasa1);
    idcasa.next();

    QString idcasa2;
    idcasa2=idcasa.value(0).toString();


    QString insertfoto;
    insertfoto="insert into fotocasa(ruta,idCasa,datosf)values('"+rutanueva+"','"+idcasa2+"',:datos);   ";
    QSqlQuery insertfoto1;
    insertfoto1.prepare(insertfoto);
    insertfoto1.bindValue(":datos",imagen2);
    if(imagen2.isNull())
    {
        QMessageBox info;
                 info.setWindowTitle("Informacion");
                 info.setText("Ne has agregado una foto");
                 info.setStandardButtons(QMessageBox::Ok);
                 info.setDefaultButton(QMessageBox::Ok);
                 info.setButtonText(QMessageBox::Ok,"Aceptar");
                 info.exec();
    }
    else
    {
        insertfoto1.exec();
        QMessageBox info;
                 info.setWindowTitle("Informacion");
                 info.setText("se inserto con exito");
                 info.setStandardButtons(QMessageBox::Ok);
                 info.setDefaultButton(QMessageBox::Ok);
                 info.setButtonText(QMessageBox::Ok,"Aceptar");
                 info.exec();

    }




    QSqlQuery fotocasa;
    QString fotocasa1;
    fotocasa1="select datosf,id from fotocasa where idCasa='"+idcasa2+"'; ";
    fotocasa.exec(fotocasa1);
    QString idfoto;

    QByteArray foto1;
    QPixmap imagen;
    int counterf=0;
    int counterc=0;
    while(fotocasa.next())
    {

        foto1=fotocasa.value(0).toByteArray();
        idfoto=fotocasa.value(1).toString();
        imagen.loadFromData(foto1);
        QIcon foto2(imagen);

        QPushButton *h = new QPushButton();

        ui->gridLayout_5->addWidget(h , counterf, counterc, 1, 1);

        h->setFixedSize(100, 100);
        h->setIcon(foto2);
        h->setIconSize(QSize(100,100));
        h->setStyleSheet("background-color: rgba(255,255,255,0);");
        QSignalMapper *mapper=new QSignalMapper(this);
        connect(h,SIGNAL(clicked(bool)),mapper,SLOT(map()));
        mapper->setMapping(h,idfoto);
        connect(mapper,SIGNAL(mapped(QString)),this,SLOT(eliminarfoto(QString)));

        counterc++;

        if (counterc == 3){
            counterf= counterf + 2;
            counterc = 0;
        }
    }





}

void RentaFacil::on_btnHabilitarReserva_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void RentaFacil::on_btnAtras_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void RentaFacil::on_btnActivar_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(16);
}

void RentaFacil::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}

//ejecucuon de la funcion de elimanr foto
void RentaFacil::eliminarfoto(QString idfotof)
{

    QMessageBox msgBox(QMessageBox::Question,"Alerta","¿Esta seguro de eliminar la foto?",QMessageBox::Yes|QMessageBox::No);
        msgBox.setButtonText(QMessageBox::Yes,"Si");
        msgBox.setButtonText(QMessageBox::No,"No");
        if(msgBox.exec()==QMessageBox::Yes) {
            QString borrar;
            borrar="delete from fotocasa where id='"+idfotof+"'; ";
            QSqlQuery borra;
            borra.exec(borrar);

            QMessageBox info;
                     info.setWindowTitle("Informacion");
                     info.setText("se elimino con exito");
                     info.setStandardButtons(QMessageBox::Ok);
                     info.setDefaultButton(QMessageBox::Ok);
                     info.setButtonText(QMessageBox::Ok,"Aceptar");
                     info.exec();





        }
        else{



        }

clearLayout(ui->gridLayout_5);

    //aqui se muestran las fotos:
        QString buscarid;
        buscarid="select id from Direccion where domicilio='"+ui->lineUbicacionModifica->text()+"'; ";
        QSqlQuery busid;
        busid.exec(buscarid);
        busid.next();

        QString iddir;
        iddir=busid.value(0).toString();

        QSqlQuery idcasa;
        QString idcasa1;
        idcasa1="select id from Casa where idDireccion='"+iddir+"'; ";
        idcasa.exec(idcasa1);
        idcasa.next();

        QString idcasa2;
        idcasa2=idcasa.value(0).toString();
        QSqlQuery fotocasa;
        QString fotocasa1;
        fotocasa1="select datosf,id from fotocasa where idCasa='"+idcasa2+"'; ";
        fotocasa.exec(fotocasa1);
        QString idfotoc;



        QByteArray foto1;
        QPixmap imagen;
        int counterf=0;
        int counterc=0;
        while(fotocasa.next())
        {

            foto1=fotocasa.value(0).toByteArray();
            idfotoc=fotocasa.value(1).toString();
            imagen.loadFromData(foto1);
            QIcon foto2(imagen);

            QPushButton *h = new QPushButton();

            ui->gridLayout_5->addWidget(h , counterf, counterc, 1, 1);

            h->setFixedSize(100, 100);
            h->setIcon(foto2);
            h->setIconSize(QSize(100,100));
            h->setStyleSheet("background-color: rgba(255,255,255,0);");
            QSignalMapper *mapper=new QSignalMapper(this);
            connect(h,SIGNAL(clicked(bool)),mapper,SLOT(map()));
            mapper->setMapping(h,idfotoc);
            connect(mapper,SIGNAL(mapped(QString)),this,SLOT(eliminarfoto(QString)));

            counterc++;

            if (counterc == 3){
                counterf= counterf + 2;
                counterc = 0;
            }
        }



}

void RentaFacil::on_btnAdelante_clicked()
{


   if( album.next())
   {
     fotoContador++;
   QByteArray fotoalbum;
   fotoalbum=album.value(0).toByteArray();
   QPixmap fotoal;
   fotoal.loadFromData(fotoalbum);

   ui->label_11->setPixmap(fotoal.scaled(215,175));
}
   else
   {

   }




}



void RentaFacil::on_btnAtras_clicked()
{
    if(album.previous())
    {
     fotoContador++;
   QByteArray fotoalbum;
   fotoalbum=album.value(0).toByteArray();
   QPixmap fotoal;
   fotoal.loadFromData(fotoalbum);

   ui->label_11->setPixmap(fotoal.scaled(215,175));
}
    else
    {

    }


}
