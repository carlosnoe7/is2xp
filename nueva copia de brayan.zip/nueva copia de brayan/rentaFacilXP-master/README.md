# rentaFacilXP
aplicación de escritorio para renta de casas en QT
